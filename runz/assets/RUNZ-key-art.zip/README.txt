RUNZ KEY ART
Last updated: October 28, 2026

Steam store and library capsules, the textless library hero and the transparent logo.
Layered PSD source files are coming soon.

runz-main-capsule-1232x706.jpg      Steam main capsule
runz-header-capsule-920x430.jpg     Steam header capsule
runz-small-capsule-462x174.jpg      Steam small capsule
runz-vertical-capsule-748x896.jpg   Steam vertical capsule
runz-library-capsule-600x900.jpg    Steam library capsule (box art)
runz-library-hero-3840x1240.jpg     Steam library hero, no logo
runz-logo-transparent-1800x519.png  Logo on transparency
runz-logo-transparent-3600x1038.png Logo on transparency, 2x (nearest neighbour)
runz-icon-512x512.png               Icon

Press contact: sardin.ventures@gmail.com
